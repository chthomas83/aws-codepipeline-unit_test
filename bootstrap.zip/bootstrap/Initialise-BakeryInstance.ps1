$context = (Get-Content -Raw -Path "$PSScriptRoot\context.json" | ConvertFrom-Json)
$config = (Get-Content -Raw -Path "$PSScriptRoot\config.json" | ConvertFrom-Json)
$environmentConfig = $config.($context.EnvironmentType)

Add-Member -InputObject $context -Name RequiresRestart -Value $false -MemberType NoteProperty

#Import the modules required by init scripts (this takes a while)
Write-Host "Loading required PowerShell modules..."
Import-Module (Join-Path $env:ProgramData -ChildPath "Amazon\EC2-Windows\Launch\Module\Ec2Launch.psd1")
Import-Module ScheduledTasks
Import-Module AWSPowerShell
Write-Host "Finished loading PowerShell modules."

Write-Host "Initialising log file: AUBakeryInstanceInitialisation.log"
Initialize-Log -Filename "AUBakeryInstanceInitialisation.log"

$scheduleName = "Bakery EC2 - Initialise Instance"
# Remove existing scheduled execution
# Register-ScriptScheduler -Function $MyInvocation.MyCommand.Definition -ScheduleName $scheduleName -Unregister

$scripts = @(
    "$PSScriptRoot\Scripts\Set-DnsConfig.ps1",
    "$PSScriptRoot\Scripts\Set-DriveLetters.ps1",
    "$PSScriptRoot\Scripts\Set-HostName.ps1",
    "$PSScriptRoot\Scripts\Join-Domain.ps1",
    "$PSScriptRoot\Scripts\Install-SophosAV.ps1",
    "$PSScriptRoot\Scripts\Install-QualysCloudAgent.ps1"    
)

#Execute script and reboot if necessary
foreach($script in $scripts){
    $scriptArgs = @{
        Context=$context;
        Config=$environmentConfig;
    }

    Write-Log "Starting execution of script: $script"
    Write-Host "Starting execution of script: $script"
    try { 
        $scriptOutput = & $script @scriptArgs
        if($scriptOutput) {
            Write-Log "Script output from $script $([Environment]::NewLine)  $($scriptOutput -join "$([Environment]::NewLine)  ")"
            Write-Host "Script output from $script $([Environment]::NewLine)  $($scriptOutput -join "$([Environment]::NewLine)  ")"
        }
    }
    catch {
        Write-Log "Execution of script: $script resulted in an error $([Environment]::NewLine) $_"
        Write-Host "Execution of script: $script resulted in an error $([Environment]::NewLine) $_"
    }
    finally {
        Write-Log "Finished execution of script: $script"
        Write-Host "Finished execution of script: $script"
    }   
    

    #If restart required - schedule init process to run on next boot unless UserData is going to run on every boot anyway
    if([bool]$context.RequiresRestart -eq $true) {
        if(-not (Get-ScheduledTask -TaskName "Amazon Ec2 Launch - Userdata Execution" -ErrorAction SilentlyContinue)) {
            Register-ScriptScheduler -ScriptPath $MyInvocation.MyCommand.Definition -ScheduleName $scheduleName
        }
        Write-Log "Script execution requires restart. Initialise process will restart after computer is restarted."
        Write-Host "Script execution requires restart. Initialise process will restart after computer is restarted."
        Restart-Computer
        exit(0)
    }
}