param (
    [PSObject]$Context,
    [PSObject]$Config
)

#Check if Sophos is already installed
$sophosServices = Get-Service | Where-Object Name -eq "SAVService" | Select-Object -First 1

#If not already installed and install file is available the install
if((Test-Path $Config.Sophos.InstallerPath) -and -not $sophosServices) {
    $installerArgs = @(
        "--quiet"
    )
    if($Config.Sophos.MessageRelays) {
        $installerArgs  += "--messagerelays=$($config.Sophos.MessageRelays)"
    }

    Write-Output "Installing Sophos AV"
    $installProcess = Start-Process -Wait -PassThru `
        -Filepath  $config.Sophos.InstallerPath `
        -ArgumentList $installerArgs
    $installProcess.WaitForExit()

    if($installProcess.ExitCode -ne 0){
        throw "Sophos installation failed with exit code: $($installProcess.ExitCode)"
    } else {
        do {
            Start-Sleep -Seconds 1
            $sophosAvSvc = Get-Service | Where-Object Name -eq "SAVService" | Select-Object -First 1
            $loopCount = $loopCount + 1
        } until( ($sophosAvSvc -and $sophosAvSvc.Status -eq [System.ServiceProcess.ServiceControllerStatus]::Running) -or $loopCount -gt 30)

        if($loopCount -gt 30) {
            throw "Timed out waiting for Sophos AV service to start. Installation may not have completed successfully."
        }

        Write-Output "Installing Sophos AV completed."
    }
} else {
    Write-Output "Sophos AV service is running and appears to already be installed."
}