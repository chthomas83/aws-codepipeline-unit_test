param (
    [PSObject]$Context,
    [PSObject]$Config
)

#If drive letter map has been provided in context then attempt to setup the drive letters
if($Context.DriveLetterMap) {    
    $disks = Get-Disk | ? IsSystem -eq $False
    $unformattedDisks = $disks | ? NumberOfPartitions -eq 0
    if($unformattedDisks) {
        C:\ProgramData\Amazon\EC2-Windows\Launch\Scripts\InitializeDisks.ps1
        foreach($dsk in $unformattedDisks) { 
            $newPart = Get-Partition -DiskNumber $dsk.DiskNumber
            #Remove the automatic drive letter that gets assigned when disk is initialised
            Remove-PartitionAccessPath -DiskNumber $newPart.DiskNumber -PartitionNumber $newPart.PartitionNumber -AccessPath "$($newPart.DriveLetter):"
        }
        #Update disk info
        $disks = Get-Disk | ? IsSystem -eq $False
    }
    
    foreach($dsk in $disks) {
        #Get the EBS device name for the current disk
        $vals = C:\ProgramData\Amazon\Tools\ebsnvme-id.exe $($dsk.DiskNumber) | `
            ? { $_.Trim().Length -gt 0 } | `
            % { $parts = $_ -split ':'; @{ ($parts[0]).Trim()=($parts[1]).Trim() } }

        $deviceName = $vals."Device Name"

        #Assign the desired drive letter
        $wantedDriveLetter = $context.DriveLetterMap.$deviceName
        $partition = (Get-Partition -DiskNumber $($dsk.DiskNumber) | Select-Object -First 1)
        if($wantedDriveLetter -ne $partition.DriveLetter) {
            Set-Partition -DiskNumber $($dsk.DiskNumber) -PartitionNumber $($partition.PartitionNumber) -NewDriveLetter $wantedDriveLetter
        }
    }
}