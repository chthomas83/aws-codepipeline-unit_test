param (
    [PSObject]$Context,
    [PSObject]$Config
)

if($Config.DNS){
    #Check Primary and Secondary DNS
    $netAdapter = Get-NetAdapter | Where-Object Status -eq Up | Select-Object -First 1
    
    if($Config.DNS.ServerAddresses) {
        $existingDnsServerAddress = (Get-DnsClientServerAddress -InterfaceIndex ($netAdapter.ifIndex) -AddressFamily IPv4 | Select-Object -First 1).ServerAddresses
        Write-Output "Found existing DNS server addresses: $($existingDnsServerAddress -join ',')"

        #This will override existing settings
        $missingAddresses = $Config.DNS.ServerAddresses | Where-Object {$existingDnsServerAddress -notcontains $_ }
        if($missingAddresses) {
            Set-DnsClientServerAddress -InterfaceIndex ($netAdapter.ifIndex) -ServerAddresses $Config.Dns.ServerAddresses
            Write-Output "Updated DNS server addresses: $($missingAddresses -join ',')"
        }
    }
           
    if($Config.DNS.Suffixes){
        $existingDnsSuffixSearchList = (Get-DnsClientGlobalSetting).SuffixSearchList
        Write-Output "Found existing DNS suffix search list: $($existingDnsSuffixSearchList -join ',')"

        #This will append the missing values
        $missingSuffixes = $Config.DNS.Suffixes | Where-Object {$existingDnsSuffixSearchList -notcontains $_ }
        if($missingSuffixes) {
            $newSuffixSearchList = $existingDnsSuffixSearchList + $missingSuffixes
            Set-DnsClientGlobalSetting -SuffixSearchList $newSuffixSearchList

            Write-Output "Updated DNS suffix search list to: $($newSuffixSearchList -join ',')"
        }
    }
}