param (
    [PSObject]$Context,
    [PSObject]$Config
)

# The hostname should look like AWSA-NPESCD. Start by adding AWS as the Prefix of the Cloud provider 
$hostName = 'AWS'

# Create a session token lasting six hours (21,600 seconds) using the PUT request and store the session token header in a variable named token
$token = Invoke-RestMethod -Headers @{"X-aws-ec2-metadata-token-ttl-seconds" = "21600"} -Method PUT -uri http://169.254.169.254/latest/api/token

# Request the availability zone of the instance
$availabilityZone = Invoke-RestMethod -Headers @{"X-aws-ec2-metadata-token" = $token} -Method GET -uri http://169.254.169.254/latest/meta-data/placement/availability-zone

# Apply regex and pull out the zone suffix
$availabilityZone -match "\w+\-\w+\-\d(\w)"
$zoneSuffix = $Matches[1].ToUpper()

# Add the suffic to the end of the hostname
$hostName += $zoneSuffix + '-'

# Query metadata for instanceId
$instanceId = (invoke-webrequest http://169.254.169.254/latest/meta-data/instance-id -UseBasicParsing).content

# Query the EC2 TAG API for the environment
$envCode = (get-ec2tag -filter @{Name="resource-id";Value=$instanceid},@{Name="key";Value="env:code"}).Value

# Query the EC2 TAG API for the instance tag Name and apply regex to extract the app identifier as well as the counter
# $instanceName = (get-ec2tag -filter @{Name="resource-id";Value=$instanceid},@{Name="key";Value="Name"}).Value -split "-"
# $appIdentifier = $instanceName[-2].ToUpper().substring(0,3)
# $counter = $instanceName[-1]

$hostName += $envCode.toUpper() + $instanceId.substring($instanceId.length-7, 7).toUpper()
$Context.HostName = $hostName

$pattern = "^(?![0-9]{1,15}$)[a-zA-Z0-9-]{1,15}$"

$systemCfg = Get-WmiObject -Class Win32_ComputerSystem
# $content = [IO.File]::ReadAllText("$PSScriptRoot\..\context.json") | ConvertFrom-Json
# $content = $Context | ConvertFrom-Json
# $content.HostName = $hostName
# $content = $content | ConvertTo-Json
$content = $Context | ConvertTo-Json
# New-Item -Path . -Name "context.json" -ItemType "file" -Value $Context -Force
New-Item -Path . -Name "context.json" -ItemType "file" -Value $content -Force

# Verify Name Value satisfies best practices for Windows hostnames
If ($hostName -match $pattern) 
    {
    Try
        {
            Rename-Computer -NewName $hostName -Restart:$false -ErrorAction Stop
            Write-Output "Hostname changed from $($systemCfg.Name) to $($hostName). Restart requested."
        } 
    Catch
        {
            $ErrorMessage = $_.Exception.Message
            Write-Output "Rename failed: $ErrorMessage"
        }
    }
Else
    {
        Throw "Provided name not a valid hostname. Please ensure Name value is between 1 and 15 characters in length and contains only alphanumeric or hyphen characters"
    }