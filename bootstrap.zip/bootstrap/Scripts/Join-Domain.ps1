param (
    [PSObject]$Context,
    [PSObject]$Config
)

#$context = Get-Content -Raw -Path c:\cfn\cfn-context.json | ConvertFrom-Json
if($Context.JoinToDomain -and $Context.JoinToDomain -eq $true) {    
    #Check if machine is already joined to a domain
    $systemCfg = (Get-WmiObject -Class Win32_ComputerSystem)
    if($systemCfg.Domain -eq "WORKGROUP") {
        $domainJoinUser = ($config.($context.EnvironmentType).DomainJoin.DomainName)+"\"+(Get-SSMParameter -Name "/au/domain_join/user_account_name").Value
        $domainJoinPass = (Get-SSMParameter -Name "/au/domain_join/user_account_password" -WithDecryption $true).Value

        $secpasswd = ConvertTo-SecureString $domainJoinPass -AsPlainText -Force
        $joinCredentials = New-Object System.Management.Automation.PSCredential ($domainJoinUser, $secpasswd)
        $domainJoinPass = $null

        $domainJoinParams = @{
            Credential = $joinCredentials;
            DomainName = $Config.DomainJoin.DomainName;            
        }

        if($Config.DomainJoin.OUPath){
            $domainJoinParams["OUPath"] = $Config.DomainJoin.OUPath
        }

        if($Config.DomainJoin.Server){
            $domainJoinParams["Server"] = $Config.DomainJoin.Server
        }

        # if machine has been renamed but not yet restarted set NewName parameter
        if($systemCfg.Name -ne $Context.HostName) {
           $domainJoinParams.NewName = $Context.HostName
        }

        Add-Computer @domainJoinParams
        $Context.RequiresRestart = $true
    }
}