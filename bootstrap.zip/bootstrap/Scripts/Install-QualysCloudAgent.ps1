param (
    [PSObject]$Context,
    [PSObject]$Config
)

#Check if already installed
$qualysAgentSvc = Get-Service | Where-Object Name -eq "QualysAgent"

#If not already installed and install file is available
if((Test-Path $Config.Qualys.InstallerPath) -and -not $qualysAgentSvc) {
    Write-Output "Installing Qualys Agent"
    $installProcess = Start-Process -Wait -PassThru `
        -Filepath  $Config.Qualys.InstallerPath `
        -ArgumentList @("CustomerId=$($Config.Qualys.CustomerId)", "ActivationId=$($Config.Qualys.ActivationId)")
    $installProcess.WaitForExit()
    
    if($installProcess.ExitCode -ne 0){
        throw "Qualys installation failed with exit code: $($installProcess.ExitCode)"
    } else {
        #Wait for service to enter started state
        $loopCount = 0
        do {
            Start-Sleep -Seconds 1
            $qualysAgentSvc = Get-Service | Where-Object Name -eq "QualysAgent"
            $loopCount = $loopCount + 1
        } until( ($qualysAgentSvc -and $qualysAgentSvc.Status -eq [System.ServiceProcess.ServiceControllerStatus]::Running) -or $loopCount -gt 30)

        if($loopCount -gt 30) {
            throw "Timed out waiting for Qualys Agent service to start. Installation may not have completed successfully."
        }

        Write-Output "Installing Qualys agent completed."
    }
} else {
    Write-Output "Qualys agent service is running and appears to already be installed."
}
